function myfunc1() {
    const prod1 = document.querySelector(".p1add");
    document.querySelector(".Productadd1").classList.toggle("Productremoved");

    if (prod1.innerHTML === "REMOVE") {
        prod1.innerHTML = "ADD";
    } else {
        prod1.innerHTML = "REMOVE";
        // Make an AJAX request to call the Flask route
        fetch('/customer_main_add')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log(data); // You can handle the response data here if needed
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
    }
}


  function myfunc2() {

    const prod2 = document.querySelector(".p2add")
    document.querySelector(".Productadd2").classList.toggle("Productremoved");

    if (prod2.innerHTML === "REMOVE"){
         prod2.innerHTML = "ADD";  
    }

    else{
        prod2.innerHTML = "REMOVE";
    }

  }

  function myfunc3() {

    const prod3 = document.querySelector(".p3add")
    document.querySelector(".Productadd3").classList.toggle("Productremoved");

    if (prod3.innerHTML === "REMOVE"){
         prod3.innerHTML = "ADD";  
    }

    else{
        prod3.innerHTML = "REMOVE";
    }

  }

  function myfunc4() {

    const prod4 = document.querySelector(".p4add")
    document.querySelector(".Productadd4").classList.toggle("Productremoved");

    if (prod4.innerHTML === "REMOVE"){
         prod4.innerHTML = "ADD";  
    }

    else{
        prod4.innerHTML = "REMOVE";
    }

  }


  function myfunc5() {

    const prod5 = document.querySelector(".p5add")
    document.querySelector(".Productadd5").classList.toggle("Productremoved");

    if (prod5.innerHTML === "REMOVE"){
         prod5.innerHTML = "ADD";  
    }

    else{
        prod5.innerHTML = "REMOVE";
    }

  }


  function myfunc6() {

    const prod6 = document.querySelector(".p6add")
    document.querySelector(".Productadd6").classList.toggle("Productremoved");

    if (prod6.innerHTML === "REMOVE"){
         prod6.innerHTML = "ADD";  
    }

    else{
        prod6.innerHTML = "REMOVE";
    }

  }



  function myfunc7() {

    const prod7 = document.querySelector(".p7add")
    document.querySelector(".Productadd7").classList.toggle("Productremoved");

    if (prod7.innerHTML === "REMOVE"){
         prod7.innerHTML = "ADD";  
    }

    else{
        prod7.innerHTML = "REMOVE";
    }

  }



  function myfunc8() {

    const prod8 = document.querySelector(".p8add")
    document.querySelector(".Productadd8").classList.toggle("Productremoved");

    if (prod8.innerHTML === "REMOVE"){
         prod8.innerHTML = "ADD";  
    }

    else{
        prod8.innerHTML = "REMOVE";
    }

  }




function myfunction(){
    document.querySelector(".formSuccesfull").innerHTML = " item added to cart";

}









