DELIMITER //

CREATE TRIGGER AfterFailedLoginAttempt AFTER INSERT ON FailedLoginAttempts
FOR EACH ROW
BEGIN
    DECLARE attempts INT;
    
    -- Count the number of failed login attempts for the user within the last 30 minutes
    SET attempts = (
        SELECT COUNT(*) 
        FROM FailedLoginAttempts 
        WHERE username = NEW.username 
        OR timestamp >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
    );
    
    -- Check if the number of failed attempts is greater than or equal to 3
    IF attempts >= 3 THEN
        -- Update the account status to 'Blocked' in the Customers table
        UPDATE Customers 
        SET AccountStatus = 'Blocked' 
        WHERE Username = NEW.username;
    END IF;
END;
//

DELIMITER ;
















DELIMITER //

CREATE TRIGGER AddToUserCartAfterCustomerInsert
AFTER INSERT ON Customers
FOR EACH ROW
BEGIN
    -- Insert the new customer's username and initial price into user_cart
    INSERT INTO user_cart (username, total_price) VALUES (NEW.Username, 0.00);
END;
//

DELIMITER ;






DELIMITER //

CREATE TRIGGER add_payment_details
AFTER INSERT ON Customers
FOR EACH ROW
BEGIN
    DECLARE order_id INT;

    -- Check if the inserted row has a valid username
    IF NEW.Username IS NOT NULL THEN
        -- Insert default payment details for the new customer
        INSERT INTO Payments (Username, OrderID, PaymentMethodStatus, Amount, Date)
        VALUES (NEW.Username, NULL, NULL, 0.00, CURRENT_DATE());
    END IF;
END;
//

DELIMITER ;

