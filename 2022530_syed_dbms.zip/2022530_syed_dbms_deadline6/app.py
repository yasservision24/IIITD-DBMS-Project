from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
from mysql.connector import IntegrityError
from flask import jsonify 
from decimal import Decimal

import time

app = Flask(__name__)

# Connect to MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="AIR@HEATER",
    database="blinkcart"
)
  

@app.route('/')
def index():
    return render_template('index.html')

def get_all_products():
    try:
        # Establish MySQL connection
        # Create a cursor object to execute queries
        cursor = db.cursor()

        # Execute the query to fetch products
        cursor.execute("SELECT * FROM Products")

        # Fetch all products from the database
        products = cursor.fetchall()

        # Close cursor and connection
        cursor.close()
        db.close()
        

        return products

    except Exception as e:
        print("Error fetching products:", e)
        return []


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="AIR@HEATER",
        database="blinkcart"
)
        
        # Create a cursor object to execute SQL queries
        cursor = db.cursor()

        # Execute the SQL command to create the trigger
       

        # Commit the changes to the database
        db.commit()

        # Close the cursor
        cursor.close()

        # Handle the login form submission
        username = request.form['username']
        password = request.form['password']

        # Check if the username exists in the database
        cursor = db.cursor()
        query = "SELECT * FROM Customers WHERE Username = %s"
        cursor.execute(query, (username,))
        user = cursor.fetchone()
        
        cursor.close()

        if user:
            if user[7] == 'Blocked':
                error = "Your account is blocked due to multiple wrong password attempts. Please contact support for assistance."
                return render_template('index.html', error=error)
                
            # Check if the password matches
            if user[1] == password:  # Assuming password is at index 2
                print(user[2])
                cursor = db.cursor()
                cursor.execute("DELETE FROM FailedLoginAttempts WHERE username = %s", (username,))

                db.commit()
                cursor.close()
                products = get_all_products()
    # Render the main template with the fetched products
    
                # Password matches, render the main page
                return render_template('main.html',username=user[0], name=user[2],customer_address=user[5],products=products,pin=user[6])
            else:
                # Password does not match, show error
                cursor = db.cursor()
                cursor.execute("INSERT INTO FailedLoginAttempts (username) VALUES (%s)", (username,))
                db.commit()
                cursor.close()
                error = "Incorrect password. Please try again."
                return render_template('index.html', error=error)
                
        else:
            # Username does not exist, show error
            error = "Username does not exist. Please sign up first."
            return render_template('index.html', error=error)
            
    # If it's a GET request, just render the login page
    return render_template('index.html')
    # If it's a GET request, just render the login page
 

        
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        name = request.form['name']
        mobile = request.form['mobile']
        email = request.form['email']
        address = request.form['address']
        pin_code = request.form['pin_code']

        try:
            # Insert data into the database
            cursor = db.cursor()
            cursor.execute("INSERT INTO Customers (Username, Password, Name, Mobile, Email, Address, Pin_Code) VALUES (%s, %s, %s, %s, %s, %s, %s)", (username, password, name, mobile, email, address, pin_code))
            db.commit()
            cursor.close()

            return render_template('registration_successfull.html') # Redirect to the index page after signup

        except IntegrityError as e:
            # Handle primary key violation error
            error = "Username already exists. Please choose a different username."
            return render_template('signup.html', error=error)

        except Exception as e:
            # Handle other database errors
            error = "An error occurred while signing up. Please try again later."
            return render_template('signup.html', error=error)

    return render_template('signup.html')


@app.route('/admin_login',methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        # Create a cursor object to execute SQL queries
        cursor = db.cursor()

        # Execute the SQL command to create the trigger
       
       

        # Commit the changes to the database
        db.commit()

        # Close the cursor
        cursor.close()

        # Handle the login form submission
        admin_id = request.form['adminid']
        password = request.form['password']

        # Check if the username exists in the database
        cursor = db.cursor()
        query = "SELECT * FROM Admins WHERE AdminID = %s"
        cursor.execute(query, (admin_id,))
        user = cursor.fetchone()
        
        cursor.close()
        print(user[1])
        if user:
            
        #     if user[7] == 'Blocked':
        #         error = "Your account is blocked due to multiple wrong password attempts. Please contact support for assistance."
        #         return render_template('index.html', error=error)
                
            # Check if the password matches
            if user[1] == password:  # Assuming password is at index 2
               
                # cursor = db.cursor()
                # cursor.execute("DELETE FROM FailedLoginAttempts WHERE username = %s", (username,))

                # db.commit()
                # cursor.close()
                # Password matches, render the main page
                return render_template('admin_main.html', name=user[2])
            else:
                # Password does not match, show error
                # cursor = db.cursor()
                # cursor.execute("INSERT INTO FailedLoginAttempts (username) VALUES (%s)", (username,))
                # db.commit()
                # cursor.close()
                error = "Incorrect password. Please try again."
                return render_template('index.html', error=error)
            
        else:
            # Username does not exist, show error
            error = "Username does not exist. Please sign up first."
            return render_template('index.html', error=error)
    
     
# If it's a GET request, just render the login page
    return render_template('admin_login.html')
# If it's a GET request, just render the login page

@app.route('/Customer_main') # not working
def customer_main():
    username=request.form['username']
    customer_address=request.form['address']
    name=request.form['name']
    products = get_all_products()
    return render_template('main.html',username=username, name=name,customer_address=customer_address,products=products)
    
    
    

def get_all_producs():
    try:
        # Establish MySQL connection
        # Create a cursor object to execute queries
        cursor = db.cursor()

        # Execute the query to fetch products
        cursor.execute("SELECT * FROM Products")

        # Fetch all products from the database
        products = cursor.fetchall()

        # Close cursor and connection
        cursor.close()
        db.close()

        return products

    except Exception as e:
        print("Error fetching products:", e)
        return []


# Function to add items to cart
def add_to_cart(username, product_id, product_name, quantity, price_per_unit, total_price, img_url):
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="AIR@HEATER",
        database="blinkcart"
    )
    cursor = db.cursor()

    # Check if the user's cart exists
    cursor.execute("SELECT * FROM user_cart WHERE username = %s", (username,))
    cart_exists = cursor.fetchone()

    # If the user's cart does not exist, create one
    if not cart_exists:
        cursor.execute("INSERT INTO user_cart (username, total_price) VALUES (%s, 0)", (username,))
        db.commit()

    # Add item to cart_items table
    cursor.execute("INSERT INTO cart_items (username, product_id, product_name, quantity, price_per_unit, total_price, image_url) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                   (username, product_id, product_name, quantity, price_per_unit, total_price, img_url))
    db.commit()

    # Update total price in user_cart table
    cursor.execute("UPDATE user_cart SET total_price = total_price + %s WHERE username = %s", (total_price, username))
    db.commit()

    cursor.close()

# Route to handle adding items to the cart
@app.route('/add_to_cart', methods=['POST'])
def add_to_cart_route():
    if request.method == 'POST':
        # Get form data
        username = request.form['username']
        product_id = int(request.form['product_id'])
        product_name = request.form['product_name']
        quantity = int(request.form['quantity'])
        price_per_unit = float(request.form['price_per_unit'])
        total_price = quantity*price_per_unit
        img_url = request.form['img_url']

        # Call add_to_cart function
        add_to_cart(username, product_id, product_name, quantity, price_per_unit, total_price, img_url)

        # Redirect to the products page or any other page
        return '', 204

@app.route('/checkout')
def checkout():
    
    # Get the username from the query parameters
    username = request.args.get('username')
    
    db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="AIR@HEATER",
    database="blinkcart"
)

    # Fetch cart data from the database based on the username
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM user_cart WHERE username = %s", (username,))
    cart_data = cursor.fetchone()
    
    if cart_data:
        cart_total = cart_data['total_price']

        # Fetch cart items from the database based on the username
        cursor.execute("SELECT * FROM cart_items WHERE username = %s", (username,))
        cart_items = cursor.fetchall()
    else:
        cart_total = 0
        cart_items = []
    cursor.execute("SELECT pin_code FROM customers WHERE username = %s", (username,))
    pin_data = cursor.fetchone()
    
    pin = pin_data['pin_code'] if pin_data else None

    cursor.close()
    
    cursor = db.cursor()
    query = "SELECT Name FROM Customers WHERE Username = %s"

        # Execute the SQL query with the username as parameter
    cursor.execute(query, (username,))

        # Fetch the result
    result = cursor.fetchone()

    if result:
            # Extract the name from the result and print it
        name = result[0]
        print("Name:", name)
    else:
        print("No user found with the username:", username)
    

    return render_template('checkout.html', username=username, cart_total=cart_total, cart_items=cart_items,pin=pin,name=name)


def remove_cart_item(cart_item_id):
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="AIR@HEATER",
        database="blinkcart"
    )
    cursor = db.cursor()

    try:
        # Retrieve the item details before removing it
        cursor.execute("SELECT * FROM cart_items WHERE cart_item_id = %s", (cart_item_id,))
        cart_item = cursor.fetchone()
        
        # If the item exists, remove it from the cart_items table
        if cart_item:
            cursor.execute("DELETE FROM cart_items WHERE cart_item_id = %s", (cart_item_id,))
            
            db.commit()
            
            # Update the total price in the user_cart table
            cursor.execute("UPDATE user_cart SET total_price = total_price - %s WHERE username = %s", 
                           (cart_item[6], cart_item[1]))
            print(cart_item[0])
            db.commit()
    except mysql.connector.Error as err:
        print("Error:", err)
        # Handle the error as needed
        

    cursor.close()
    db.close()


@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    if request.method == 'POST':
        # Get the cart item ID from the form data
        cart_item_id = request.form['cart_item_id']
        username=request.form['username']
       
        
        # Call a function to remove the item from the cart
        remove_cart_item(cart_item_id)
        
        # Redirect the user to the cart page or any other desired page
        return redirect(url_for('checkout', username=username))  # Assuming '/cart' is the URL for the cart page

from flask import request, redirect, url_for

@app.route('/place_order', methods=['POST'])
def place_order():
    if request.method == 'POST':
        # Retrieve order details from the form data
        username = request.form['username']
        cart_total = request.form['cart_total']
        
        db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="AIR@HEATER",
        database="blinkcart"
    )
        
        cursor = db.cursor()

        # SQL query to retrieve the name based on the username
        query = "SELECT Name FROM Customers WHERE Username = %s"

        # Execute the SQL query with the username as parameter
        cursor.execute(query, (username,))

        # Fetch the result
        result = cursor.fetchone()

        if result:
            # Extract the name from the result and print it
            name = result[0]
           
        else:
            print("No user found with the username:", username)
        
       
        return render_template('payment.html', username=username, cart_total=cart_total,name=name)




# Function to retrieve customer details by username
import mysql.connector
import random
from flask import request, redirect

# Function to retrieve customer details based on the username
def get_customer_details(username):
    try:
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="AIR@HEATER",
            database="blinkcart"
        )
        cursor = db.cursor(dictionary=True)

        # Retrieve customer details based on the username
        cursor.execute("SELECT * FROM Customers WHERE Username = %s", (username,))
        customer_data = cursor.fetchone()

        cursor.close()
        db.close()
        
        return customer_data
    except mysql.connector.Error as err:
        print("Error:", err)
        return None

# Function to retrieve an available delivery agent
def get_available_delivery_agent():
    try:
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="AIR@HEATER",
            database="blinkcart"
        )
        cursor = db.cursor(dictionary=True)

        # Retrieve an available delivery agent
        cursor.execute("SELECT * FROM DeliveryAgents WHERE Availability = 1")
        delivery_agent = cursor.fetchone()

        # cursor.close()
        # db.close()
        
        return delivery_agent
    except mysql.connector.Error as err:
        print("Error:", err)
        return None

# Function to create a new order and insert into the database
def create_order(username, customer_data, total_amount, status, payment_method):
    try:
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="AIR@HEATER",
            database="blinkcart"
        )
        cursor = db.cursor()

        # Retrieve an available delivery agent
        delivery_agent = get_available_delivery_agent()

        if delivery_agent:
            delivery_agent_id = delivery_agent['DeliveryAgentID']
            print(delivery_agent_id)
        else:
            delivery_agent_id = None
        orderid = random.randint(1000, 9999)  
        # Insert order details into the Orders table
        cursor.execute("INSERT INTO Orders (orderid,Username, TotalAmount, Status, ShippingAddress, Pin_Code, DeliveryAgentID, payment_method) VALUES (%s, %s, %s, %s, %s, %s, %s,%s)", (orderid,username, total_amount, status, customer_data['Address'], customer_data['Pin_Code'], delivery_agent_id, payment_method))
        db.commit()

        # Retrieve the OrderID of the newly inserted order
        

        # Insert payment details into the Payments table
        cursor.execute("INSERT INTO Payments (Username, OrderID, PaymentMethodStatus, Amount, Date) VALUES (%s, %s, %s, %s, CURDATE())", (username, orderid, payment_method, total_amount))
        db.commit()

        # Extract product details from the form data (assuming it's a list of dictionaries)
        cursor.execute("SELECT product_id, product_name, quantity, price_per_unit, total_price, image_url FROM cart_items WHERE username = %s", (username,))
        order_items = cursor.fetchall()

        # Insert order items into the order_counts table
        for item in order_items:
            cursor.execute("INSERT INTO order_counts (order_id, product_id, product_name, quantity, price_per_unit, product_image_url) VALUES (%s, %s, %s, %s, %s, %s)", (orderid, item[0], item[1], item[2], item[3], item[5]))
            db.commit()
            
            
            
        # Delete entries from user_cart and cart_items tables
        cursor.execute("DELETE FROM cart_items WHERE username = %s", (username,))
        db.commit()

        cursor.execute("DELETE FROM user_cart WHERE username = %s", (username,))
        db.commit()
        for item in order_items:
            cursor.execute("UPDATE products SET quantity = quantity - %s WHERE productid = %s", (item[2], item[0]))
            print(item[0])
            print(item[2])
            db.commit()
        cursor.close()
        db.close()
    except mysql.connector.Error as err:
        print("Error:", err)


# Route to handle order placement
from threading import Lock

# Dictionary to store locks for each product ID
product_locks = {}

@app.route('/orders', methods=['POST'])
def orders():
    if request.method == 'POST':
        # Extract username from the form data
        username = request.form['username']
        
        # Retrieve customer details based on the username
        customer_data = get_customer_details(username)

        if customer_data:
            # Extract other order details from the form data
            total_amount = request.form['cart_total']
            status = 'Pending'  # Assuming the order status is initially set to 'Pending'
            payment_method = request.form['paymentOptions']

            try:
                # Connect to the database
                db = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="AIR@HEATER",
                    database="blinkcart"
                )
                cursor = db.cursor()

                # Fetch product IDs associated with the order from cart_items table
                cursor.execute("SELECT product_id FROM cart_items WHERE username = %s", (username,))
                product_ids = [row[0] for row in cursor.fetchall()]

                # Acquire locks for each product ID
                acquired_locks = []
                for product_id in product_ids:
                    product_locks.setdefault(product_id, Lock())
                    product_lock = product_locks[product_id]
                    product_lock.acquire()
                    acquired_locks.append(product_lock)

                # Call the function to create and insert the order into the database
                create_order(username, customer_data, total_amount, status, payment_method)

            # Redirect the user to a success page or any other desired page
                order_details = get_order_details(get_latest_order_id(username))
                # Perform order-related operations here

                # Release locks after completing operations
                for lock in acquired_locks:
                    lock.release()

                # Redirect the user to the success page with order details
                
                return render_template('success.html', order_details=order_details)

            except Exception as e:
                # Rollback and release locks in case of errors
                for lock in acquired_locks:
                    lock.release()
                return render_template('error.html', error_message=str(e))
            finally:
                cursor.close()
                db.close()

        else:
            # Handle the case where customer data is not found
            return "Customer data not found"



def get_order_details(order_id):
    try:
        db = mysql.connector.connect(
            host="localhost",
            user="root",

            
            password="AIR@HEATER",
            database="blinkcart"
        )
        cursor = db.cursor(dictionary=True)

        # Retrieve order details based on the order ID
        cursor.execute("SELECT * FROM Orders WHERE OrderID = %s", (order_id,))
        order_data = cursor.fetchone()

        # Retrieve product details associated with the order from the order_counts table
        cursor.execute("SELECT * FROM order_counts WHERE order_id = %s", (order_id,))
        order_items = cursor.fetchall()

        cursor.close()
        db.close()

        return order_data, order_items
    except mysql.connector.Error as err:
        print("Error:", err)
        return None, None
    
def get_latest_order_id(username):
    try:
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="AIR@HEATER",
            database="blinkcart"
        )
        cursor = db.cursor()

        # Retrieve the order ID of the most recent order for the given username
        cursor.execute("""
            SELECT OrderID
            FROM Orders
            WHERE Username = %s
            ORDER BY order_date DESC
            LIMIT 1
        """, (username,))
        latest_order_id = cursor.fetchone()[0]  # Fetch the first column of the first row

        cursor.close()
        db.close()
        
        return latest_order_id
    except mysql.connector.Error as err:
        print("Error:", err)
        return None

@app.route('/customer_analysis')
def customer_analysis():
    # Fetch data from customers, payments, and orders tables
    db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="AIR@HEATER",
            database="blinkcart"
        )
    cursor = db.cursor()
    try:
        # Connect to the database
        
        cursor = db.cursor(dictionary=True)

        # Query to retrieve customer data, order data, and payment data
        query = """
            SELECT 
    C.Username, C.Name, C.Email,
    O.OrderID, O.TotalAmount, O.Status, O.order_date,
    P.PaymentMethodStatus
FROM 
    Customers C
LEFT JOIN 
    Orders O ON C.Username = O.Username
LEFT JOIN 
    Payments P ON O.OrderID = P.OrderID;

        """
        cursor.execute(query)
        customers = cursor.fetchall()

        # Close the cursor and database connection
        cursor.close()
        db.close()

        # Render the customer analysis template with the retrieved data
        print(customers)
        
        return render_template('customer_analysis.html', data=customers,)

    except mysql.connector.Error as err:
        print("Error:", err)
        # Handle the error as needed
        return "An error occurred while fetching customer data."




@app.route('/inventory_analysis')
def inventory_analysis():
    # Fetch data from customers, payments, and orders tables
    db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="AIR@HEATER",
            database="blinkcart"
        )
    cursor = db.cursor()
    try:
        # Connect to the database
        
        cursor = db.cursor(dictionary=True)

        # Query to retrieve customer data, order data, and payment data
        query = """
           SELECT * FROM Products

        """
        cursor.execute(query)
        products = cursor.fetchall()

        # Close the cursor and database connection
        cursor.close()
        db.close()

        # Render the customer analysis template with the retrieved data
        print(products)
        
        return render_template('inventory_analysis.html', data=products)

    except mysql.connector.Error as err:
        print("Error:", err)
        # Handle the error as needed
        return "An error occurred while fetching customer data."

@app.route('/add_product_to_inventory')
def add_product_to_inventory():
    return render_template('add_product_to_inventory.html')

import threading

# Create a threading lock object

inventory_lock={}
@app.route('/add_product_to_inventory_final_step', methods=['POST'])
def add_product_to_inventory_final_step():
    if request.method == 'POST':
        try:
            # Retrieve form data
            product_id = request.form['product_id']
            inventory_lock.setdefault(product_id, threading.Lock())
            inven_lock = inventory_lock[product_id]
            inven_lock.acquire()
            
            # Acquire the lock around product_id generation
            
            try:
                # Connect to the database
                db = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="AIR@HEATER",
                    database="blinkcart"
                )
                cursor = db.cursor()

                # Retrieve other form data
                name = request.form['name']
                description = request.form['description']
                supplier_id = request.form['supplier_id']
                price = request.form['price']
                quantity = request.form['quantity']
                img_link = request.form['img_link']
                weight = request.form['weight']

                # Insert the product into the database
                cursor.execute("INSERT INTO products (productid, name, description, supplierid, price, quantity, imagelink, weight) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)", 
                            (product_id, name, description, supplier_id, price, quantity, img_link, weight))
                db.commit()
                return render_template('admin_main.html')
            finally:
                # Release the lock
                inven_lock.release()

        except IntegrityError as e:
            db.rollback()  # Rollback the transaction in case of duplicate product ID
            return render_template('error.html', error_message="A product with this ID already exists. Please use a different ID.")
        except Exception as e:
            db.rollback()  # Rollback the transaction in case of other errors
            return render_template('error.html', error_message=str(e))
        finally:
            # Close database connection
            cursor.close()
            db.close()
    else:
        return render_template('add_product_to_inventory.html')



@app.route('/update_product')
def update_product():
    # Here you can render the HTML form to modify the product details
    return render_template('update_product.html')
 

import threading

# Create a threading lock object
product_quantity_locks = {}
product_price_locks = {}

@app.route('/update_product_final', methods=['GET', 'POST'])
def update_product_final():
    if request.method == 'POST':
        # Retrieve form data
        product_id = request.form['product_id']
        price_change = Decimal(request.form['price']) # Convert price_change to a float
        quantity_change = Decimal(request.form['quantity'])  # Convert quantity_change to an integer

        # Acquire locks for the product quantity and price separately
        product_quantity_locks.setdefault(product_id, threading.Lock())
        product_price_locks.setdefault(product_id, threading.Lock())
        

        quantity_lock = product_quantity_locks[product_id]
        price_lock = product_price_locks[product_id]
        quantity_lock.acquire()
        price_lock.acquire()

        try:
            # Connect to the database
            db = mysql.connector.connect(
                host="localhost",
                user="root",
                password="AIR@HEATER",
                database="blinkcart"
            )
            cursor = db.cursor()

            # Fetch the current quantity and price from the database
            cursor.execute("SELECT quantity FROM products WHERE productid = %s", (product_id,))
            current_quantity = cursor.fetchone()[0]
            current_quantity=Decimal(current_quantity)
            cursor.execute("SELECT price FROM products WHERE productid = %s", (product_id,))
            current_price = cursor.fetchone()[0]

            
            new_quantity = current_quantity + quantity_change
            new_price = current_price + price_change

            # Update the product quantity in the database
            cursor.execute(
                "UPDATE products SET quantity = %s WHERE productid = %s",
                (new_quantity, product_id)
            )
            

            # Update the product price in the database
            cursor.execute(
                "UPDATE products SET price = %s WHERE productid = %s",
                (new_price, product_id)
            )
           

            return render_template('admin_main.html')

        except Exception as e:
            db.rollback()  # Rollback the transaction in case of errors
            return render_template('error.html', error_message=str(e))
        finally:
            # Release the locks for the product quantity and price
            db.commit()
            
            quantity_lock.release()
            price_lock.release()
            cursor.close()
            db.close()

    else:
        # Render the HTML form to modify the product details
        return render_template('update_product.html')




   
    
    



# if __name__ == '__main__':
#     app.run(debug=True)

from flask import Flask, render_template, request, jsonify
from pyngrok import ngrok

from flask import Flask, render_template, request, jsonify
from pyngrok import ngrok






@app.route('/api/data', methods=['POST'])
def api_data():
    data = request.json
    response = {'message': f"Received data: {data}"}
    return jsonify(response)

if __name__ == "__main__":
    port = 5000

    # Start ngrok tunnel
    public_url = ngrok.connect(port)
    print(f"Your ngrok public URL is: {public_url}")

    # Run Flask app
    app.run(port=port)