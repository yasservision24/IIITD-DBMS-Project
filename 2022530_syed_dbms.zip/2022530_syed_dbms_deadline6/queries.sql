CREATE DATABASE BLINKCART;

CREATE TABLE FailedLoginAttempts (--
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE FailedLoginAttempts (
    username VARCHAR(255) PRIMARY KEY,
    attempt_count INT DEFAULT 0
);  

CREATE TABLE user_cart (--
    username VARCHAR(255) PRIMARY KEY,
    total_price DECIMAL(10, 2)
);

-- Suppliers

-- Query to create the Suppliers table

CREATE TABLE Suppliers (--
    SupplierID INT PRIMARY KEY NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL,
    SuppliersAddress VARCHAR(255) NOT NULL,
    Mobile VARCHAR(20) NOT NULL,
    Email VARCHAR(255) NOT NULL
);

-- Insert

INSERT INTO Suppliers (SupplierID, Password, Name, SuppliersAddress, Mobile, Email)--
VALUES 
    (1, 'supplier1pass', 'Supplier 1', '123 Main St', '1234567890', 'supplier1@example.com'),
    (2, 'supplier2pass', 'Supplier 2', '456 Elm St', '0987654321', 'supplier2@example.com'),
    (3, 'supplier3pass', 'Supplier 3', '789 Oak St', '5551234567', 'supplier3@example.com'),
    (4, 'supplier4pass', 'Supplier 4', '321 Pine St', '9876543210', 'supplier4@example.com'),
    (5, 'supplier5pass', 'Supplier 5', '678 Maple St', '5555555555', 'supplier5@example.com'),
    (6, 'supplier6pass', 'Supplier 6', '987 Cedar St', '1112223333', 'supplier6@example.com'),
    (7, 'supplier7pass', 'Supplier 7', '456 Birch St', '4445556666', 'supplier7@example.com'),
    (8, 'supplier8pass', 'Supplier 8', '234 Oak St', '7778889999', 'supplier8@example.com'),
    (9, 'supplier9pass', 'Supplier 9', '890 Pine St', '8889990000', 'supplier9@example.com'),
    (10, 'supplier10pass', 'Supplier 10', '567 Elm St', '9990001111', 'supplier10@example.com');

-- Products

-- Query to create the Products table

CCREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Description TEXT,
    SupplierID INT NOT NULL,
    Price DECIMAL(10, 2) CHECK (Price > 0) NOT NULL,
    Ratings VARCHAR(255),
    Quantity DECIMAL(10, 2) CHECK (Quantity > 0) NOT NULL,
    ImageLink VARCHAR(255),
    Weight VARCHAR(255) NOT NULL DEFAULT '0',
    FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID)
);

-- Step 3: Insert data into the Products table
INSERT INTO Products (ProductID, Name, Description, SupplierID, Price, Ratings, Quantity, ImageLink, Weight)
VALUES 
    (1, 'Product 1', 'Description of Product 1', 1, 10.99, '4.5', 500, 'product1.png', '500g'),
    (2, 'Product 2', 'Description of Product 2', 2, 20.99, '4.8', 1000, 'product2.png', '1 ltr'),
    (3, 'Product 3', 'Description of Product 3', 3, 15.99, '4.3', 250, 'product3.png', '250g'),
    (4, 'Product 4', 'Description of Product 4', 5, 12.99, '4.2', 750, 'product4.png', '750ml'),
    (5, 'Product 5', 'Description of Product 5', 5, 18.99, '4.6', 200, 'product5.png', '200g'),
    (6, 'Product 6', 'Description of Product 6', 1, 25.99, '4.7', 1000, 'product6.png', '1 kg'),
    (7, 'Product 7', 'Description of Product 7', 7, 14.99, '4.4', 2000, 'product7.png', '2 ltr'),
    (8, 'Product 8', 'Description of Product 8', 2, 22.99, '4.9', 500, 'product8.png', '500ml');

-- Customers

-- Query to create the  Customers table

CREATE TABLE Customers (
    Username VARCHAR(255) PRIMARY KEY NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL,
    Mobile VARCHAR(20) NOT NULL,
    Email VARCHAR(255) NOT NULL,
    Address VARCHAR(255) NOT NULL,
    Pin_Code INT NOT NULL,
    AccountStatus VARCHAR(50) DEFAULT 'Active' NOT NULL
);


-- DeliveryAgents

-- Query to make DeliveryAgents table

CREATE TABLE DeliveryAgents (--
    DeliveryAgentID INT PRIMARY KEY NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL,
    Mobile VARCHAR(20) NOT NULL,
    Email VARCHAR(255) NOT NULL,
    Ratings FLOAT CHECK (Ratings >= 0 AND Ratings <= 5),
    Availability BOOLEAN NOT NULL,
    OrderID VARCHAR(255)
);



-- Insert

INSERT INTO DeliveryAgents (DeliveryAgentID, Password, Name, Mobile, Email, Ratings, Availability, OrderID)--
VALUES 
    (1, 'agent123', 'John Smith', '123-456-7890', 'john@example.com', 4.5, true,'5,8,9' ),
    (2, 'agent456', 'Alice Johnson', '987-654-3210', 'alice@example.com', 4.2, true, '6'),
    (3, 'agent789', 'Bob Anderson', '555-555-5555', 'bob@example.com', 4.7, false, '3'),
    (4, 'agent987', 'Jane Smith', '777-777-7777', 'jane@example.com', 4.0, true, NULL),
    (5, 'agent567', 'Michael Brown', '111-222-3333', 'michael@example.com', 4.8, true, '7'),
    (6, 'agent234', 'Lisa Johnson', '444-555-6666', 'lisa@example.com', 4.3, true, '10'),
    (7, 'agent890', 'Tom Anderson', '999-888-7777', 'tom@example.com', 4.6, true, NULL),
    (8, 'agent765', 'Emily Wilson', '666-555-4444', 'emily@example.com', 4.1, false, NULL),
    (9, 'agent321', 'Susan Jones', '888-999-0000', 'susan@example.com', 4.4, true, NULL),
    (10, 'agent543', 'Peter Clark', '222-333-4444', 'peter@example.com', 4.9, true, NULL);




CREATE TABLE cart_items (--
    cart_item_id SERIAL PRIMARY KEY,
    username VARCHAR(255),
    product_id INT,
    product_name VARCHAR(255),
    quantity INT,
    price_per_unit DECIMAL(10, 2),
    total_price DECIMAL(10, 2),
    image_url VARCHAR(255), -- Add column to store image URL
    FOREIGN KEY (username) REFERENCES user_cart(username)
);


CREATE TABLE Orders (--
    OrderID INT PRIMARY KEY,
    Username VARCHAR(255) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    TotalAmount DECIMAL(10, 2) NOT NULL,
    Status VARCHAR(255) NOT NULL,
    ShippingAddress VARCHAR(255) NOT NULL,
    Pin_Code INT NOT NULL,
    DeliveryAgentID INT,
    payment_method VARCHAR(50),
    FOREIGN KEY (Username) REFERENCES Customers(Username),
    FOREIGN KEY (DeliveryAgentID) REFERENCES DeliveryAgents(DeliveryAgentID)
);

CREATE TABLE order_counts (--
    order_count SERIAL PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    price_per_unit DECIMAL(10, 2),
    product_name VARCHAR(255),
    product_image_url VARCHAR(255),
    -- Add other fields as needed
    FOREIGN KEY (order_id) REFERENCES Orders(OrderID),
    FOREIGN KEY (product_id) REFERENCES Products(productid)
);




CREATE TABLE Payments (--
    Username VARCHAR(255) NOT NULL,
    OrderID INT ,
    PaymentMethodStatus VARCHAR(255),
    Amount DECIMAL(10, 2) NOT NULL,
    Date  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Username) REFERENCES Customers(Username),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

-- Admins

-- Query to make Admins table

CREATE TABLE Admins (--
    AdminID INT PRIMARY KEY NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL
);

-- Insert

INSERT INTO Admins (AdminID, Password, Name, Email)--
VALUES 
    (1, 'admin123', 'John Doe', 'john_admin@example.com'),
    (2, 'admin456', 'Jane Smith', 'jane_admin@example.com'),
    (3, 'admin789', 'Alice Johnson', 'alice_admin@example.com'),
    (4, 'admin987', 'Bob Anderson', 'bob_admin@example.com'),
    (5, 'admin654', 'Michael Brown', 'michael_admin@example.com'),
    (6, 'admin321', 'Lisa Johnson', 'lisa_admin@example.com'),
    (7, 'admin890', 'Tom Anderson', 'tom_admin@example.com'),
    (8, 'admin765', 'Emily Wilson', 'emily_admin@example.com'),
    (9, 'admin234', 'Susan Jones', 'susan_admin@example.com'),
    (10, 'admin543', 'Peter Clark', 'peter_admin@example.com');



















 